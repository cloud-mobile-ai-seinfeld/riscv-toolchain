// See LICENSE for license details.

// help out poor, C-centric autoconf
extern "C" void libfesvr_is_present() {}
