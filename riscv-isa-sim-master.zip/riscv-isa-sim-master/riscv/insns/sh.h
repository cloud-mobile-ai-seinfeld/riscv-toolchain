MMU.store_uint16(RS1 + insn.s_imm(), RS2);
