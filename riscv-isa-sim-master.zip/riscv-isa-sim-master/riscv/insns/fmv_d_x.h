require_extension('D');
require_rv64;
require_fp;
WRITE_FRD(f64(RS1));
