// vdotu vd, vs2, vs1
VI_VV_ULOOP
({
  vd += vs2 * vs1;
})
