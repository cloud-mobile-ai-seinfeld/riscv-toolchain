// vaadd.vx vd, vs2, rs1
VI_VVX_LOOP_AVG(rs1, +, false);
