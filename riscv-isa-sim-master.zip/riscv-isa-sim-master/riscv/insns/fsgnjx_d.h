require_extension('D');
require_fp;
WRITE_FRD(fsgnj64(FRS1, FRS2, false, true));
