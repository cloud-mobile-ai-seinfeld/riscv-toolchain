//vamoswape.v vd, (rs1), vs2, vd
VI_AMO({ return vs3; }, uint, e64);
