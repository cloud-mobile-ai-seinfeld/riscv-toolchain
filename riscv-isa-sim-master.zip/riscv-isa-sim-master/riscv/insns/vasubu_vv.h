// vasubu.vv vd, vs2, vs1
VI_VVX_ULOOP_AVG(vs1, -, true);
