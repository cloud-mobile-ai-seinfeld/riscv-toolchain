// vand.vv vd, vs1, vs2, vm
VI_VV_LOOP
({
  vd = vs1 & vs2;
})
