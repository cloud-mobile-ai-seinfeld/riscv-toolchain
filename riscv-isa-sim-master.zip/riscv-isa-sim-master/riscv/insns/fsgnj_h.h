require_extension(EXT_ZFH);
require_fp;
WRITE_FRD(fsgnj16(FRS1, FRS2, false, false));
