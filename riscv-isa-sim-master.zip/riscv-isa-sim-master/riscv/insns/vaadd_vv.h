// vaadd.vv vd, vs2, vs1
VI_VVX_LOOP_AVG(vs1, +, true);
